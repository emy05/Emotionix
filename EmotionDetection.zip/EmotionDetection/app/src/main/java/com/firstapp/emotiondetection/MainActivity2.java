package com.firstapp.emotiondetection;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity implements PopupMenu.OnMenuItemClickListener {
    TextView tx4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        createNotificationChannel();
        tx4 = (TextView) findViewById(R.id.textView4);
        registerForContextMenu(tx4);
        Button button=findViewById(R.id.button5);
        button.setOnClickListener(v -> {
Toast.makeText(this,"Reminder to Journal!",Toast.LENGTH_SHORT).show();
Intent intent=new Intent(MainActivity2.this,ReminderBroadcast.class);
PendingIntent pendingIntent=PendingIntent.getBroadcast(MainActivity2.this,0,intent,PendingIntent.FLAG_IMMUTABLE);
            AlarmManager alarmManager=(AlarmManager) getSystemService(ALARM_SERVICE);
            long timeAtButtonClick=System.currentTimeMillis();
            long tenSecondsInMillis = 1000*10;
            alarmManager.set(AlarmManager.RTC_WAKEUP,timeAtButtonClick+tenSecondsInMillis,pendingIntent);
        });
    }
    public void createNotificationChannel(){
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            CharSequence name="ReminderChannel";
            String description="Channel for Reminder";
            int importance= NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel=new NotificationChannel("notifyMe",name,importance);
            channel.setDescription(description);

            NotificationManager notificationManager=getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        getMenuInflater().inflate(R.menu.menu2,menu);
    }
    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        Intent about = null;
        switch(item.getItemId()){
            case R.id.option1:
                about=new Intent(this,AboutUs.class);
                break;
            case R.id.option2:
              about=new Intent(this,ProjectDesc.class);
                break;

        }
        startActivity(about);
        return true;
    }
    @Override
    public boolean onCreatePanelMenu(int featureId, Menu menu) {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.menu_file,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId()){
            case R.id.aboutus:
                Toast.makeText(MainActivity2.this,"About Us",Toast.LENGTH_SHORT).show();
                return true;
            case R.id.projectdescription:
                Toast.makeText(MainActivity2.this,"Project Description",Toast.LENGTH_SHORT).show();
                return true;
            case R.id.teamdetails:
                Toast.makeText(MainActivity2.this,"Team Details",Toast.LENGTH_SHORT).show();
                return true;
            case R.id.teammembers:
                Intent team=new Intent(this,TeamMembers.class);
                startActivity(team);
            case R.id.aboutmembers:
                Toast.makeText(MainActivity2.this,"About Members",Toast.LENGTH_SHORT).show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    public void ourteam(View v){
        PopupMenu popup=new PopupMenu(this,v);
        popup.setOnMenuItemClickListener(this);
        popup.inflate(R.menu.popup_menu);
        popup.show();
    }


    @Override
    public boolean onMenuItemClick(MenuItem item) {
       switch(item.getItemId()){
           case R.id.itemone:
             Toast.makeText(this,"We EMY PREMLIN A, VIJI M, UPPRETTA S, NAGASREE R A, B.TECH IT Students Of TCE",Toast.LENGTH_LONG).show();
             return true;
           case R.id.itemtwo:
               Toast.makeText(this,"Contact us through www.emotionix.com",Toast.LENGTH_LONG).show();
           default:
               return false;

       }
    }
}